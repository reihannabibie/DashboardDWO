<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Grafik Vendor - Rata-rata Waktu Pengiriman</title>

    <!-- Custom fonts for this template-->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/startbootstrap-sb-admin-2/4.1.3/css/sb-admin-2.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/styleGraph.css">

    <!-- Highcharts -->
    <script src="https://code.highcharts.com/highcharts.js"></script>
    <script src="https://code.highcharts.com/modules/data.js"></script>
    <script src="https://code.highcharts.com/modules/drilldown.js"></script>
    <script src="https://code.highcharts.com/modules/exporting.js"></script>
    <script src="https://code.highcharts.com/modules/export-data.js"></script>
    <script src="https://code.highcharts.com/modules/accessibility.js"></script>
</head>

<body>

    <!-- Sidebar -->
    

    <!-- Content -->
    <body id="page-top">
    <div id="wrapper">
        <!-- Sidebar -->
        <?php include 'sidebar.php'; ?>

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">
            <div id="content">
                <!-- Topbar (optional) -->
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">
                    <h1 class="h3 mb-0 text-gray-800">Dashboard Adventure Work</h1>
                </nav>

                <!-- Main Content -->
                <div class="container-fluid">
                    <!-- Grafik Penjualan -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Grafik Pembelian per Vendor</h6>
                        </div>
                        <div class="card-body">
                            <div id="grafik-vendor" style="width: 100%; height: 400px;"></div>
                        </div>
                    </div>
                </div>
            </div>
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; Dashboard Reihan & Irfan</span>
                    </div>
                </div>
            </footer>
        </div>
    </div>

    <!-- Grafik -->
    <script>
    // Ambil data dari file PHP menggunakan AJAX
    fetch('data_vendor.php')
    .then(response => response.json())
    .then(data => {
        if (data.error) {
            console.warn('Error:', data.error);
            Highcharts.chart('grafik-vendor', {
                chart: { type: 'bar' },
                title: { text: 'Data Tidak Tersedia' },
                subtitle: { text: data.error },
                series: []
            });
            return;
        }

        const vendors = data.map(item => item.vendor_name);
        const avgPurchases = data.map(item => parseFloat(item.avg_purchase) || 0);

        // Define a color palette
        const colors = [
            '#FF5733', '#33FF57', '#3357FF', '#FF33A1', '#FFD633', '#33FFF6', '#FF6B33', 
            '#FFB833', '#33B5FF', '#33FF9E', '#FF33FF', '#FF8C33', '#8C33FF', '#FF3344'
        ];

        // Ensure the number of colors matches the number of vendors
        const chartColors = vendors.map((_, index) => colors[index % colors.length]);

        Highcharts.chart('grafik-vendor', {
            chart: { type: 'bar' },
            title: { text: 'Rata-rata Jumlah Pembelian per Vendor' },
            subtitle: { text: 'Sumber: AdventureWorks 2019' },
            xAxis: {
                categories: vendors,
                title: { text: 'Vendor' }
            },
            yAxis: {
                min: 0,
                title: {
                    text: 'Rata-rata Jumlah Pembelian',
                    align: 'high'
                },
                labels: { overflow: 'justify' }
            },
            tooltip: { valuePrefix: 'Rp ' },
            plotOptions: {
                bar: { dataLabels: { enabled: true } }
            },
            legend: { enabled: false },
            credits: { enabled: false },
            series: [{
                name: 'Rata-rata Pembelian',
                data: avgPurchases,
                colorByPoint: true,  // Ensures each bar has a different color
                colors: chartColors  // Apply the color array
            }]
        });
    })
    .catch(error => {
        console.error('Error:', error);
        Highcharts.chart('grafik-vendor', {
            chart: { type: 'bar' },
            title: { text: 'Terjadi Kesalahan' },
            subtitle: { text: 'Tidak dapat mengambil data dari server.' },
            series: []
        });
    });
</script>


</body>

</html>
