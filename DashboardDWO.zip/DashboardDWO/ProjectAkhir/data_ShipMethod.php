<?php
// Koneksi ke database
require_once("koneksipurchase.php");

// Query untuk menghitung total pembelian berdasarkan metode pengiriman
$sql = "
    SELECT 
        s.ShipName, 
        SUM(f.AmountPurchase) AS total_purchase
    FROM fact_purchase f
    JOIN shipmethod s ON f.ShipMethodID = s.ShipMethodID
    GROUP BY s.ShipName
    ORDER BY total_purchase DESC
";

try {
    $result = $conn->query($sql);

    if (!$result || !$result->num_rows > 0) {
        throw new Exception("Tidak ada data ditemukan");
    } 

    $data = array();
    
    while ($row = $result->fetch_assoc()) {
        $data[] = $row;  
    }

    header('Content-Type: application/json');   
    echo json_encode(array_map(function($value){return ['shipname' => $value['ShipName'], 'total_purchase' => $value['total_purchase']];},$data),JSON_PRETTY_PRINT);

} catch(Exception $e){
     http_response_code(500);
     die(json_encode(['error'=>$e->getMessage()]));
}
finally{
   $conn->close();  
}
