 <!-- Sidebar -->
<style>
    .sidebar {
        background: linear-gradient(135deg, #3b3b98, #373799); /* Gradient warna biru elegan */
        color: #f5f6fa; /* Teks putih */
    }

    .sidebar .nav-link {
        color: #f5f6fa; /* Warna teks */
    }

    .sidebar .nav-link:hover {
        background-color: #273c75; /* Warna latar saat hover */
        border-radius: 5px; /* Membuat sudut tombol membulat */
    }

    .sidebar-heading {
        color: #dcdde1; /* Warna abu terang */
        font-weight: bold; /* Teks tebal untuk heading */
        margin-top: 10px; /* Jarak ke atas */
    }

    .sidebar .nav-link i {
        color: #f5f6fa; /* Ikon dengan warna putih */
    }

    .sidebar .sidebar-brand {
        background: #40739e; /* Warna lebih gelap untuk header */
        padding: 15px;
        border-radius: 5px;
        margin-bottom: 10px;
    }

    .sidebar .sidebar-brand-icon {
        color: #dcdde1; /* Warna ikon lebih terang */
    }

    .sidebar .sidebar-divider {
        border-color: #dcdde1; /* Divider lebih terang */
    }
</style>

 <ul class="navbar-nav bg-gradient-dark sidebar sidebar-dark accordion" id="accordionSidebar">

     <!-- Sidebar - Brand -->
     <a class="sidebar-brand d-flex align-items-center justify-content-center" href="home.php">
         <div class="sidebar-brand-icon rotate-n-15">
         <i class="fas fa-user"></i>
         </div>
         <div class="sidebar-brand-text mx-3">ADVENTURE WORK</div>
     </a>

     <!-- Divider -->
     <hr class="sidebar-divider">

     <!-- Heading User Profile-->
     <div class="sidebar-heading">
         Grafik Data ADVENTURE WORK
     </div>

     <!-- Nav Item - My Profile -->
     <li class="nav-item">
         <a class="nav-link" href="TotalPenjualan.php">
         <i class="fas fa-dollar-sign"></i>
             <span>Data Penjualan Setiap Bulan</span></a>
     </li>

     <li class="nav-item">
         <a class="nav-link" href="PembelianVendor.php">
         <i class="fas fa-dollar-sign"></i>
             <span>Data Pembelian per Vendor</span></a>
     </li>

     <!-- Nav Item - Edit Profile -->
     <li class="nav-item">
         <a class="nav-link" href="PerformaKaryawan.php">
         <i class="fas fa-money-bill"></i>
             <span>Performa Karyawan Berdasarkan Penjualan</span></a>
     </li>

     <!-- Nav Item - Edit Profile -->
     <li class="nav-item">
         <a class="nav-link" href="PembelianMetode.php">
         <i class="fas fa-money-bill"></i>
             <span>Pembelian berdasarkan Metode Pengiriman</span></a>
     </li>

    <!-- Divider -->
    <hr class="sidebar-divider">

    <!-- Heading User Profile-->
    <div class="sidebar-heading">
        OLAP
    </div>

    <!-- Nav Item - My Profile -->
    <li class="nav-item">
        <a class="nav-link" href="olapsales.php">
        <i class="fas fa-database"></i>
            <span>Mondrian Sales</span></a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="olappurchase.php">
        <i class="fas fa-database"></i>
            <span>Mondrian Purchase</span></a>
    </li>
     <!-- Heading Data Customer-->

          <!-- Divider -->
          <hr class="sidebar-divider d-none d-md-block">

 
     <!-- Nav Item - Logout -->
     <li class="nav-item">
         <a class="nav-link" href="index.php">
             <i class="fas fa-sign-out-alt"></i>
             <span>Logout</span></a>
     </li>

     <!-- Divider -->
     <hr class="sidebar-divider d-none d-md-block">

     <!-- Sidebar Toggler (Sidebar) -->
     <div class="text-center d-none d-md-inline">
         <button class="rounded-circle border-0" id="sidebarToggle"></button>
     </div>


 </ul>
 <!-- End of Sidebar -->