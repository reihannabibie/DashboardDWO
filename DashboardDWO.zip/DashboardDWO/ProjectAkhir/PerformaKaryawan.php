<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Dashboard Adventure Work</title>

    <!-- Custom fonts for this template-->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/startbootstrap-sb-admin-2/4.1.3/css/sb-admin-2.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/styleGraph.css">

    <!-- Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>

<body id="page-top">
    <div id="wrapper">
        <!-- Sidebar -->
        <?php include 'sidebar.php'; ?>

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">
            <div id="content">
                <!-- Topbar -->
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">
                    <h1 class="h3 mb-0 text-gray-800">Dashboard Adventure Work</h1>
                </nav>

                <!-- Main Content -->
                <div class="container-fluid">
                    <!-- Grafik Penjualan -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Performa Karyawan Berdasarkan Total Penjualan</h6>
                        </div>
                        <div class="card-body">
                            <canvas id="barChart" style="width: 100%; height: 400px;"></canvas>
                        </div>
                    </div>
                </div>
            </div>
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; Dashboard Reihan & Irfan</span>
                    </div>
                </div>
            </footer> 
        </div>
    </div>

    <script>
    // Mendapatkan data dari file PHP
    fetch('data_EmployeeSales.php')
        .then(response => {
            if (!response.ok) {
                throw new Error("Network response was not ok. Status: " + response.status);
            }
            return response.json();
        })
        .then(data => {
            if (data.error) {
                throw new Error(data.error);
            }

            // Mengolah data untuk Chart.js
            const labels = data.map(item => item.EmployeeName); // Nama karyawan
            const totalSales = data.map(item => item.total_sales); // Total penjualan

            // Membuat warna berbeda untuk setiap bar
            const colors = [
                'rgba(75, 192, 192, 0.7)',
                'rgba(255, 99, 132, 0.7)',
                'rgba(54, 162, 235, 0.7)',
                'rgba(255, 206, 86, 0.7)',
                'rgba(153, 102, 255, 0.7)',
                'rgba(201, 203, 207, 0.7)',
                'rgba(255, 159, 64, 0.7)',
                'rgba(233, 30, 99, 0.7)',
                'rgba(0, 150, 136, 0.7)',
                'rgba(103, 58, 183, 0.7)'
            ];

            const backgroundColors = labels.map((_, index) => colors[index % colors.length]);

            const ctx = document.getElementById('barChart').getContext('2d');
            new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: labels,
                    datasets: [{
                        label: 'Total Penjualan (dalam IDR)', // Judul legenda
                        data: totalSales,
                        backgroundColor: backgroundColors, // Warna berbeda untuk setiap bar
                        borderColor: backgroundColors.map(color => color.replace('0.7', '1')), // Border warna yang sama
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    plugins: {
                        legend: {
                            display: true, // Menampilkan legenda
                            labels: {
                                color: '#000', // Warna teks hitam
                                font: {
                                    family: 'Nunito, Arial, sans-serif',
                                    size: 14,
                                    weight: 'bold' // Menebalkan teks
                                }
                            },
                            position: 'top' // Posisi legenda di atas grafik
                        },
                        tooltip: {
                            callbacks: {
                                label: function(context) {
                                    return `Total Penjualan: ${context.raw.toLocaleString('id-ID', {style: 'currency', currency: 'IDR'})}`;
                                }
                            }
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            ticks: {
                                callback: function(value) {
                                    return value.toLocaleString('id-ID', {style: 'currency', currency: 'IDR'});
                                }
                            }
                        }
                    }
                }
            });
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Gagal mengambil data: ' + error.message);
        });
</script>

</body>
</html>
