<?php
// Aktifkan error reporting untuk debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Koneksi ke database
require("koneksisales.php");

// Debug koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Query SQL untuk menghitung total penjualan per karyawan
$sql = "
    SELECT 
        e.EmployeeName, 
        SUM(f.SalesAmount) AS total_sales
    FROM dime_employee e
    JOIN factsales f ON e.EmployeeID = f.EmployeeID
    GROUP BY e.EmployeeName
    ORDER BY total_sales DESC
";

$result = $conn->query($sql);

if (!$result) {
    die(json_encode(["error" => "Query gagal: " . $conn->error]));
}

$data = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $data[] = $row;
    }
} else {
    echo json_encode(["error" => "Tidak ada data ditemukan di database."]);
    exit;
}

$conn->close();

// Mengembalikan data dalam format JSON
header('Content-Type: application/json');
echo json_encode($data, JSON_PRETTY_PRINT);
?>
